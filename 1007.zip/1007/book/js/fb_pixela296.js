var FB_PIXEL = function(){
	var ViewContent = function(){	/* 컨텐츠 조회 */
		//console.log("FB_PIXEL - ViewContent");
		if (typeof fbq != 'undefined') fbq('track', 'ViewContent');
	};
	var AddToCart = function(){	/* 장바구니 추가 */
		//console.log("FB_PIXEL - AddToCart");
		if (typeof fbq != 'undefined') fbq('track', 'AddToCart');
	};
	var AddToWishlist = function(){	/* 위시리스트 추가 */
		//console.log("FB_PIXEL - AddToWishlist");
		if (typeof fbq != 'undefined') fbq('track', 'AddToWishlist');
	};
	var InitiateCheckout = function(){	/* 결제시작 */
		//console.log("FB_PIXEL - InitiateCheckout");
		if (typeof fbq != 'undefined') fbq('track', 'InitiateCheckout');
	};
	var AddPaymentInfo = function(){	/* 결제 정보 추가 */
		//console.log("FB_PIXEL - AddPaymentInfo");
		if (typeof fbq != 'undefined') fbq('track', 'AddPaymentInfo');
	};
	var Purchase = function(value,currency){	/* 결제 완료 */
		if (typeof fbq != 'undefined') fbq('track', 'Purchase',{'value' : value, 'currency' : currency});
	};
	return {
		"ViewContent" : function(){
			ViewContent();
		},
		"AddToCart" : function(){
			AddToCart();
		},
		"AddToWishlist" : function(){
			AddToWishlist();
		},
		"InitiateCheckout" : function(){
			InitiateCheckout();
		},
		"AddPaymentInfo" : function(){
			AddPaymentInfo();
		},
		"Purchase" : function(value,currency){
			Purchase(value,currency);
		}
	}
}();