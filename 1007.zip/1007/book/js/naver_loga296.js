var _nasa = {};
var NP_LOG = function(){
	var CompletePayment = function(price){ /* 결제 및 구매 완료 */
		_nasa["cnv"] = wcs.cnv("1", price);
		npLogRequest();
	};
	var CompleteJoin = function(){ /* 회원가입 완료 */
		_nasa["cnv"] = wcs.cnv("2", "1");
		npLogRequest();
	};
	var AddToCart = function(price){ /* 장바구니 담기 완료 */
		_nasa["cnv"] = wcs.cnv("3", price);
		npLogRequest();
	};
	var CompleteReservation = function(price){ /* 신청 및 예약 완료 */
		_nasa["cnv"] = wcs.cnv("4", price);
		npLogRequest();
	};
	var EtcPage = function(){ /* 기타 페이지 */
		_nasa["cnv"] = wcs.cnv("5", "1");
		npLogRequest();
	};

	function npLogRequest(){
		wcs_do(_nasa);
	}
	return {
		"Completepayment" : function(price){
			CompletePayment(price);
		},
		"CompleteJoin" : function(){
			CompleteJoin();
		},
		"AddToCart" : function(price){
			AddToCart(price); 
		},
		"CompleteReservation" : function(price){
			CompleteReservation(price);
		},
		"EtcPage" : function(){
			EtcPage();
		}
	}
}();