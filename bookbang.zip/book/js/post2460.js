
var POST = function(){
	var code, post_body, body_input, is_notice,is_notice_input,is_secret,is_secret_input, post_form,post_subject,total_file_size;

	var $board_container,$floara_obj;
	var $post_img_library;
	var $represent_img;
	var $upload_cover_image_btn_obj, $delete_cover_image_btn_obj, $cover_image, $cover_image_tmp_no;
	var $post_secret_password;
	var $widget_wrap,board_code,listing_type,more_list_page;
	var $listing_obj,type_data;
	var option = {};


	var reaction_token, reaction_token_key;
	
	var postDeletePost = function (board_code,code,return_url,secret_pass){
		if(confirm(LOCALIZE.설명_삭제하시겠습니까())){
			$.ajax({
				type		: 'post',
				data:{'pcode':code,board_code:board_code,secret_pass:secret_pass},
				url			: '/ajax/deletePost.cm',
				dataType 	: 'json',
				success		: function(result){
					if(result.msg == 'SUCCESS'){
						window.location.href = return_url;
					}else{
						alert(result.msg);
					}
				}
			});
		}
	};


	/***
	 * 안드로이드앱에서 post글쓰기시 이미지 업로드 완료시 처리
	 * @param image
	 */

	var $image_list_obj = {};
	//이미지 임시저장 리스트 추가
	if(!($image_list_obj.length > 0)) {
		var image_list_html = $("<ul id='image_list' style='display: none'></ul>");
		$("body").append(image_list_html);
		$image_list_obj = image_list_html;
	}

	var android_que = [];
	var androidAppPostImageUploadComplete = function(image){
		if(image.tmp_idx > 0){
			android_que.push(image);
			if(image.is_last == "Y") androidAppPostImageUploadAllComplete();
		}
	};

	var androidAppPostImageUploadAllComplete = function(){
		androidAppPostImageInsert(android_que[0]);
	};

	var androidAppPostImageInsert = function(image){
		post_body.froalaEditor('image.insert', CDN_UPLOAD_URL+image.url, true);
		post_body.off('froalaEditor.image.inserted').on('froalaEditor.image.inserted', function (e, editor, $img, response) {
				if(IS_ANDROID_APP == 'Y') {
					var img = post_body.find('img[src="'+CDN_UPLOAD_URL+image.url+'"]');
					img.data(image);
					postAddImage(image.tmp_idx,image.size);
					android_que.splice(0,1);
					if (android_que.length > 0) androidAppPostImageUploadAllComplete();
				}
			});
	};

	var postAddImage = function(tmp_idx,size){
		var uniq_id = makeUniq('image_');
		var hidden_input = $('<input name="temp_images[]" value="' + tmp_idx + '" type="hidden" />');
		var li 	= $('<li>').attr('id',uniq_id).data({'item':uniq_id,size:size});
		li.append(hidden_input);
		$image_list_obj.append(li);
	};





	var postInitWrite = function(key){
		$("body").addClass("write_mode");
		$board_container = $('#board_container');
		post_body = $('#post_body');
		post_subject = $('#post_subject');
		body_input = $('#body_input');
		post_form = $('#post_form');
		$upload_cover_image_btn_obj = $('#upload_cover_image');
		$delete_cover_image_btn_obj = $('#delete_cover_image');
		$cover_image = $('#cover_image');
		$cover_image_tmp_no = $('#cover_image_tmp_no');
		code = key;
		post_subject.limitLength({max_byte:120},true);
		total_file_size = 0;
		if(IE_VERSION < 10){
			CKEDITOR.replace( 'post_body',{
				filebrowserImageUploadUrl: '/ajax/post_image_upload.cm?board_code='+key
			});
		}else{
			if(android_version() == 4){
				post_body.addClass('legacy_webview');
			}
			post_body.setFroala({
				'code' : code,
				'image_upload_url' : "/ajax/post_image_upload.cm",
				'file_upload_url' : "/ajax/post_file_upload.cm",
				'file_list_obj' : $("#file_list")
			});
		}



		// post_body.on('froalaEditor.image.inserted', function (e, editor, $img,response) {
		// 	console.log("123");
		// });


		/*
		post_body.on('froalaEditor.image.beforeUpload', function (e, editor, images) {
			alert('드래그 업로드는 지원하지 않습니다.');
			return false;
		});
		*/

		/*
		post_body.on('froalaEditor.image.uploaded', function (e, editor, images) {
			//alert('이미지 복사 붙여넣기 기능은 지원하지 않습니다.');
			//location.reload();
		});
		*/
		/*
		post_body.on('froalaEditor.image.beforePasteUpload', function (e, editor, images) {
			alert('이미지 복사 붙여넣기 기능은 지원하지 않습니다.');
			images.remove();
			//alert('이미지 복사 붙여넣기 기능은 지원하지 않습니다.');
			//return false;
		});
		*/




		function dataURLtoBlob(dataurl) {
			var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
				bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
			while(n--){
				u8arr[n] = bstr.charCodeAt(n);
			}
			return new Blob([u8arr], {type:mime});
		}

		$delete_cover_image_btn_obj.on('click',function(){
			POST.deleteCoverImage();
		});

		$upload_cover_image_btn_obj.setUploadImage({
			url : '/ajax/upload_image.cm',
			formData : {target : 'post', 'temp' : 'Y', 'param_name' : 'cover_image'}
			}, function (msg, data,res) {
				$.each(res.cover_image,function(i,file){
					if(file.tmp_idx > 0){
						$cover_image.val(file.url);
						$cover_image_tmp_no.val(file.tmp_idx);
						$delete_cover_image_btn_obj.show();
						$board_container.toggleClass('bg_on',true);
						$board_container.find('._cover_image').css('background-image',"url("+CDN_UPLOAD_URL+file.url+")");
						$board_container.find('._cover_image_src').attr('src',CDN_UPLOAD_URL+file.url);
					}
				});
			});

		$(window).off('scroll.mobile_write resize.mobile_write').on('scroll.mobile_write resize.mobile_write',function(){
			var s_top = $(this).scrollTop();
			$board_container.find('._mobile_tool_bar', '_write_header').toggleClass('m_sticky_toolbar', s_top > 45);
			$board_container.find('._write_header').toggleClass('m_sticky_toolbar', s_top > 45);
			if($board_container.hasClass('bg_on'))
				$board_container.find('#toolbarContainer').toggleClass('pc_sticky_toolbar',s_top > 487);
			else
				$board_container.find('#toolbarContainer').toggleClass('pc_sticky_toolbar',s_top > 180);

		});
	};
	var deleteCoverImage = function(){
		$cover_image.val('');
		$cover_image_tmp_no.val('');
		$board_container.toggleClass('bg_on',false);
		$board_container.find('._cover_image').css('background-image','none');
		$board_container.find('._cover_image_src').attr('src','');
		$delete_cover_image_btn_obj.hide();
	};



	var postSubmit = function(){

		if(IE_VERSION < 10){
			var body = CKEDITOR.instances.post_body.getData();
			body_input.val(body);
			post_form.submit();
		}else{
			if(post_body.hasClass('fr-code-view'))
				post_body.froalaEditor('codeView.toggle');

			var body = post_body.froalaEditor("html.get", true, true);
			body_input.val(body);
			post_form.submit();
		}
	};

	var is_more = true;
	var listing_obj = {};
	var moreList = function(keyword,keyword_type,q){
		var c_url = typeof CURRENT_URL == 'undefined' ? '' : CURRENT_URL;
		if(is_more){
			$.ajax({
				type		: 'post',
				data:{'page':more_list_page,'board_code':board_code,'keyword':keyword,'keyword_type':keyword_type, back_url:c_url, 'q':q},
				url			: '/ajax/get_post_list_type_more.cm',
				dataType 	: 'json',
				success		: function(result){
					if(result.msg == 'SUCCESS'){
						if(listing_type == "card"){
							listing_obj = $('#post_card_'+board_code);
							listing_obj.append(result.html);
							
							listing_obj.imagesLoaded().always(function() {
								listing_obj.masonry({
									itemSelector: '.ma-item'
								});

							});

							$('body').off('gridChange.'+board_code).on('gridChange.'+board_code,function(){
								listing_obj.imagesLoaded().always(function() {
									listing_obj.masonry({
										itemSelector: '.ma-item'
									});

								});
							});

						}else if(listing_type == "blog"){
							listing_obj = $('#post_blog_'+board_code);
							listing_obj.append(result.html);
						}
					}else{
						alert(result.msg);
					}
				}
			});
		}
	};


	var postInitMoreList = function(wcode,bcode,type){
		listing_type = type;
		$widget_wrap = $("#"+wcode);
		board_code = bcode;
		more_list_page = 1;
		is_more = true;
		return true;
	};

	var toggleAlarmPopup = function(){
		var $alarm_popup = $('#alarm_popup');
		var $dLabel = $('#dLabel');
		$alarm_popup.toggleClass('open');
		if($alarm_popup.hasClass('open')){
			$(window).on('click.alarm_popup',function(event){
				var $top_closest = $(event.target).closest('a');
				if($top_closest.attr('id')!='dLabel'){
					var $closest = $(event.target).closest('ul');
					if($closest != null && !$closest.hasClass('dropdown-menu')){
						$alarm_popup.removeClass('open');
						$(window).off('click.alarm_popup');
						var alarm_group_list = $alarm_popup.find("input[type='checkbox']").is(":checked");
						if(alarm_group_list) $dLabel.addClass('active');
						else $dLabel.removeClass('active');
					}
				}
			});
		}
	};
	var postDeleteFile = function(id){
		var obj = $('#'+id);
		var size = obj.data('size');
		total_file_size -= size;
		obj.remove();
	};
	var postAddFile = function(filename,file_code,tmp_idx,size){
		var uniq_id = makeUniq('upfile_');
		total_file_size += size;
		var clear_ico = $('<i class="zmdi zmdi-close"></i>').data({'item':uniq_id,size:size}).click(function(e){
			postDeleteFile(uniq_id);
		});
		var hidden_input = '';
		if(file_code.length>0) {
			hidden_input = $('<input name="upload_files[]" value="' + file_code + '" type="hidden" />');
		}else if(Math.round(tmp_idx) > 0){
			hidden_input = $('<input name="temp_files[]" value="' + tmp_idx + '" type="hidden" />');
		}
		var li 	= $('<li>').attr('id',uniq_id).data({'item':uniq_id,size:size});
		li.append($('<span>'+ filename +'<em> &nbsp;'+ GetFileSize(size) +'</em></span>'));
		li.append(clear_ico);
		li.append(hidden_input);
		$("#file_list").append(li);
	};

	var MovePostPopup = function(post_code,menu_url){
		$.ajax({
			type		: 'post',
			data:{'post_code':post_code,'menu_url':menu_url},
			url			: '/ajax/move_post_popup.cm',
			dataType 	: 'json',
			success		: function(result){
				if(result.msg == 'SUCCESS'){
					var html = $(result.html);
					$.cocoaDialog.open({type : 'site_alert', custom_popup : html});
				}else{
					alert(result.msg);
				}
			}
		});
	};

	return {
		'init' : function(code) {
			postInitWrite(code);
		},
		'initMoreList' : function(widget_code,board_code,listing_type) {
			return postInitMoreList(widget_code,board_code,listing_type);
		},
		'submit' : function(){
			postSubmit();
		},
		'addFile' : function(filename,file_code,tmp_idx,size){
			postAddFile(filename,file_code,tmp_idx,size);
		},
		'androidAppPostImageUploadComplete' :function(image){
			androidAppPostImageUploadComplete(image);
		},
		'androidAppPostImageUploadAllComplete' :function(){
			androidAppPostImageUploadAllComplete();
		},
		'deletePost' : function (board_code,code,return_url,secret_pass) {
			postDeletePost(board_code,code,return_url,secret_pass);
		},
		'moreList' : function(keyword,keyword_type,q){
			moreList(keyword,keyword_type,q);
		},
		'toggleAlarmPopup' : function(){
			toggleAlarmPopup();
		},
		'MovePostPopup' : function(post_code,menu_url){
			MovePostPopup(post_code,menu_url);
		},
		'deleteCoverImage' : function(){
			deleteCoverImage();
		},
		'deleteLibraryImage' : function(url){
			deleteLibraryImage(url);
		}
	};
}();

function POST_INIT_LIST(code,data){
	var that 	= this;
	that.type_data = data;
	that.code = code;
	that.windowWidth = $(window).width();
	that.change_timer = setTimeout(function(){},1);
	that.listing_obj = $('#post_card_'+that.code);

	that.listing_obj.imagesLoaded().always(function(ins) {
		that.listResize();
	});

	$('body').off('gridChange'+that.code).on('gridChange'+that.code,function(){
		that.listing_obj.imagesLoaded().always(function(ins) {
			that.listResize();
		});
	});

	$(window).off('resize.'+that.code).on('resize.'+that.code,function(){
		if ($(window).width() != that.windowWidth) {
			that.windowWidth = $(window).width();
		}else{
			return;
		}
		clearTimeout(that.change_timer);
		that.change_timer = setTimeout(function(){
			that.listResize();
		},1000);
	});

	this.listResize = function(){
		that.listing_obj.imagesLoaded()
			.always(function(){
				var window_width = $(window).width();
				if(!that.type_data.grid_gutter){
					that.type_data.grid_gutter = 15;
				}
				if($('body').hasClass('device_type_m'))
					window_width = 370;
				if(window_width <= 991)
					that.type_data.grid_gutter = that.type_data.grid_gutter/2;
				that.listing_obj.css({'margin':'0 -'+that.type_data.grid_gutter+'px'});
				that.listing_obj.css({'margin-top':'-'+that.type_data.grid_gutter+'px'});

				var cnt = parseInt(that.type_data.grid_col_count);
				var inner_width = that.listing_obj.width();

				if(window_width <= 991){
					if(typeof that.type_data.grid_mobile_col_count == "undefined")
						cnt = 2;
					else
						cnt = parseInt(that.type_data.grid_mobile_col_count);
				}else{
					if(that.type_data.design_type == 'slide'){
						inner_width = that.listing_obj.parent().width();
					}else{
						inner_width = that.listing_obj.width();
					}

					if(that.type_data.grid_extend_fix != 'Y'){
						var s_width = (that.type_data.max_width - (that.type_data.document_margin * 2)) + that.type_data.grid_gutter * 2;
						var item_max = s_width - ((cnt - 1) * parseInt(that.type_data.grid_gutter));
						var grid_width = Math.floor(item_max / cnt);
						var current_width = Math.floor((inner_width - ((cnt - 1) * parseInt(that.type_data.grid_gutter))) / cnt);
						if(current_width > grid_width){
							cnt = Math.floor(inner_width / grid_width);
						}
					}
				}

				var width = Math.floor(inner_width / cnt);
				if(that.type_data['design_type'] == 'grid'){
					that.listing_obj.find('._post_item_wrap').css({'padding' : that.type_data.grid_gutter + 'px'});
					that.runColSize(cnt);
				}else if(that.type_data['design_type'] == 'masonry'){
					var $masonry_item = that.listing_obj.find('.ma-item');
					var masonry_item_count = $masonry_item.length;
					that.listing_obj.find('.ma-item').css({'width' : width,'padding' : that.type_data.grid_gutter + 'px'});
					that.runMasonry(masonry_item_count);
				}
			});
	};

	this.runColSize = function(col_cnt){
		that.listing_obj.find('._card_wrap').show();
		var i = 1;
		var $_row = $('<div />').addClass('_post_row post_row tabled');
		var is_append = false;
		that.listing_obj.find('._dummy_item').remove();
		var $item = that.listing_obj.find('._card_wrap');
		var item_count = $item.length;

		$item.each(function(e,$_obj){
			$_row.append($_obj);
			is_append = false;
			if(i % col_cnt == 0){
				that.listing_obj.append($_row);
				is_append = true;
				$_row = $('<div />').addClass('_post_row post_row tabled');
			}
			i++;
		});

		if(!is_append){
			var $tmp_item = $_row.find('._post_item_wrap');
			if($tmp_item.length >0 ){
				if($tmp_item.length < col_cnt){
					var remain_cnt = col_cnt - $tmp_item.length;
					for(var i = 0; i <remain_cnt; i++){
						var $dummy_col = $('<div/>').addClass('dummy_col item_post _item _dummy_item table-cell');
						$_row.append($dummy_col);
					}
				}
				that.listing_obj.append($_row);
			}
		}

		that.listing_obj.find('._post_row').each(function(){
			var $tmp_item = $(this).find('._post_item_wrap');
			if($tmp_item.length ==0 ){
				$(this).remove();
			}
		});

		that.imgHeight();
	};

	this.imgHeight = function(){
		if(that.type_data['design_type'] == 'grid'){
			var height = Math.ceil(that.listing_obj.find('._post_item_wrap').eq(0).width() / (that.type_data.img_ratio / 100));
			that.listing_obj.find('._img_wrap').height(height);
		}
	};

	this.runMasonry = function(count){
		if(count > 0){
			that.listing_obj.on( 'layoutComplete', function() {
				that.listing_obj.css('visibility','visible');
			});
			that.listing_obj.masonry({
				itemSelector: '.ma-item'
			});
		}
	};
}