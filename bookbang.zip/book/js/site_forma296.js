var SITE_FORM = function(){
	var init = function(){
	};

	var itemFileUpload = function($obj,code){
		$obj.fileupload({
			url: '/ajax/form_file_upload.cm',
			dataType: 'json',
			singleFileUploads:false,
			limitMultiFileUploads: 1,
			dropZone: null,
			maxFileSize : 20000000, //20mb
			limitMultiFileUploadSize : 110000000, //110 mb
			formData:{'code':code},
			start: function (e, data) {},
			progress: function (e, data) {},
			done: function (e, data) {
				var form_file = '';
				form_file = 'form_file_'+code;
				if(data.result[form_file][0].size > 52428800){
					alert(LOCALIZE.설명_최대업로드용량안내());
					return;
				}
				if(data.result[form_file][0].error){
					alert(data.result[form_file][0].error);
				}else{
					if(data.result[form_file][0].tmp_idx > 0){
						$obj.find('._form_file_list').show();
						$obj.find('._holder').hide();
						$obj.find('._filename').text(data.result[form_file][0].org_name);
						$obj.find('._filesize').text('('+GetFileSize(data.result[form_file][0].size)+')');
						$obj.find('._temp_file').val(data.result[form_file][0].tmp_idx);
						$obj.find('._upload_file').val('');
					}
				}
			},
			fail: function (e, data) {}
		})
		.find('._fileremove').click(function(){
			$obj.find('._form_file_list').hide();
			$obj.find('._holder').show();
			$obj.find('._temp_file').val('');
			$obj.find('._upload_file').val('');
		});
	};

	var itemRequiredCk = function($obj){
		var required_ck = true;
		$obj.find('.form-group').each(function(){
			var type = '';
			if($(this).find('label i').hasClass('icon-required') === true){
				type = this.id.split('_');
				switch(type[0]){
					case 'privacy':
						if($('#privacy input').is(":checked") === false){
							required_ck = 'required';
							return false;
						}
						break;
					case 'input':
						if(!$(this).find('input').val()){
							required_ck = false;
							return false;
						}
						break;
					case 'textarea':
						if(!$(this).find('textarea').val()){
							required_ck = false;
							return false;
						}
						break;
					case 'radio':
						if(!$('input:radio[name="'+this.id+'"]:checked').val()){
							required_ck = false;
							return false;
						}
						break;
					case 'checkbox':
						if($("input:checkbox[name='"+this.id+"[]']").is(":checked") === false){
							required_ck = false;
							return false;
						}
						break;
					case 'file':
						if(!$("input[name='temp_files_"+type[1]+"']").val()){
							if(!$("input[name='upload_files_"+type[1]+"']").val()){
								required_ck = false;
								return false;
							}
						}
						break;
				}
			}
		});
		return required_ck;
	}

	var Formsubmit = function($obj){
		if(itemRequiredCk($obj) === true){
			$.ajax({
				type        : 'POST',
				data        : $obj.serialize(),
				url         : ('/ajax/form_add.cm'),
				dataType    : 'json',
				async       : true,
				cache       : false,
				success     : function (result){
					if(result.msg == 'SUCCESS'){
						if(result.file_code){
							$.each(result.file_code, function(k, v){
								$('input[name=upload_files_' + k + ']').val(v);
								$('input[name=temp_files_' + k + ']').val('');
							});
						}
						if(result.form_one_data_ck === true){
							if(result.form_one_data_modify_ck === true){
								$('.form-widget form').next().html(result.html);
								$obj.find('._form_input_btn').text(LOCALIZE.버튼_응답수정());
							}else{
								$('.form-widget form').next().html(result.html);
								$obj.find('._form_input_btn').remove();
							}
						}else{
							$('.form-widget form').next().html(result.html);
						}
						if(result.mode == 'edit'){
							$('input[name=idx]').val(result.old_idx);
						}else{
							$('input[name=idx]').val(result.idx);
							$('input[name=fmode]').val('modify');
						}
					}else{
						alert(result.msg);
					}
				}
			});
		}else{
			if(itemRequiredCk($obj) == 'required'){
				alert(LOCALIZE.설명_개인정보처리방침에동의하여주시기바랍니다());
			}else{
				alert(LOCALIZE.설명_필수항목을입력하여주시기바랍니다());
			}
		}
	}

	/*
	var FormResultsPremit = function(unit_code,board_code,form_code){
		$.ajax({
			type        : 'POST',
			data        : {'unit_code':unit_code,'board_code':board_code,'form_code':form_code},
			url         : ('/ajax/form_results_premit.cm'),
			dataType    : 'json',
			async       : true,
			cache       : false,
			success     : function (result) {
				$('._ResultsPremit').show();
				$('._form-widget').hide();
				$('._ResultsPremit').append(result.html);
			}
		});
	}
	*/

	return {
		init:function(){
		},
		itemFileUpload:function($obj,$code){
			itemFileUpload($obj,$code);
		},
		itemRequiredCk:function($obj){
			return itemRequiredCk($obj);
		},
		Formsubmit:function($obj){
			return Formsubmit($obj);
		}
	}
}();