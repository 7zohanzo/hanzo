var PREVIEW_MODE = function(){
	var $preview_bar;
	var $window;
	//var show = false;
	//var hide = true;
	//var hide_timeout = {};
	//var auto_hide_timeout = {};
	var init = function(){
		$preview_bar = $('#preview_mode_bar');
		$window = $(window);
	//	mouseTrigger();
	//	showBar();
	};

	/*
	var mouseTrigger = function(){
		$window.on('mousemove.preview_mode',function(e){
			if(e.clientY <100)
				showBar();
			else
				hideBar();
		})
	};
	var showBar = function(){
		clearShowBar();
		clearHideBar();
		show = true;
		hide = false;
		$preview_bar.toggleClass('show',true);
		$preview_bar.toggleClass('showing',true);
		$preview_bar
			.on("transitionend",
				function(e){
					$preview_bar.toggleClass('showing',false);
					$(this).off(e);
					auto_hide_timeout = setTimeout(function(){
						hideBar();
					},2000);
				});
	};
	var clearShowBar = function(){
		$preview_bar.off("transitionend");
		clearTimeout(auto_hide_timeout);

	};

	var clearHideBar = function(){
		$preview_bar.off("transitionend");
		clearTimeout(hide_timeout);
	};
	var hideBar = function(){
		if(!hide){
			clearShowBar();
			clearHideBar();
			hide = true;
			show = false;
			hide_timeout = setTimeout(function(){
				$preview_bar.toggleClass('show',false);
				$preview_bar.toggleClass('showing',false);
				$preview_bar.toggleClass('hiding',true);
				$preview_bar
					.on("transitionend",
						function(e){
							$preview_bar.toggleClass('hiding',false);
							$(this).off(e);
						});
			},1000);

		}
	};	*/

	var publishDesignTemp = function(){
		$.ajax({
			type: 'POST',
			data: {'mode':'publish'},
			url: ('/admin/ajax/publish_design_temp.cm'),
			dataType: 'json',
			async: true,
			cache: false,
			success: function (result) {
				if (result.msg == 'SUCCESS') {
					$preview_bar.find('._temp').hide();
					$preview_bar.find('._published').show();
				}else{
					alert(result.msg );
				}
			}
		});
	};

	var closePreviewMode = function(back_url){
		window.location.href='/backpg/close_preview_mode.cm?back_url='+back_url;
	};
	return {
		'init' : function(){
			init();
		},
		'publishDesignTemp' : function(){
			publishDesignTemp();
		},
		'closePreviewMode' : function(back_url){
			closePreviewMode(back_url);
		}
	}
}();