
var MAP = function(){
	var board_code, $map_form,total_file_size;
	var $widget_wrap,listiing_type,more_list_page;
	var $map;
	var map_data = [];
	var $map_editor;
	var $old_map_impomation;
	var map_list_current_position = {'latitude':0,'longitude':0};
	var map_pos_ck = false;


	/***
	 * 안드로이드앱에서 post글쓰기시 이미지 업로드 완료시 처리
	 * @param image
	 */

	/*
	var $image_list_obj = {};
	//이미지 임시저장 리스트 추가
	if(!($image_list_obj.length > 0)) {
		var image_list_html = $("<ul id='image_list' style='display: none'></ul>");
		$("body").append(image_list_html);
		$image_list_obj = image_list_html;
	}

	var android_que = [];
	var androidAppPostImageUploadComplete = function(image){
		if(image.tmp_idx > 0){
			android_que.push(image);
			if(image.is_last == "Y") androidAppPostImageUploadAllComplete();
		}
	};

	var androidAppPostImageUploadAllComplete = function(){
		androidAppPostImageInsert(android_que[0]);
	};

	var androidAppPostImageInsert = function(image){
		$map_editor.find('#map_body').froalaEditor('image.insert', CDN_UPLOAD_URL+image.url, true);
		var img = $froala_obj.find('img[src="'+CDN_UPLOAD_URL+image.url+'"]');
		img.data(image);
		postAddImage(image.tmp_idx,image.size);
		android_que.splice(0,1);
	};

	var postAddImage = function(tmp_idx,size){
		var uniq_id = makeUniq('image_');
		var hidden_input = $('<input name="temp_images[]" value="' + tmp_idx + '" type="hidden" />');
		var li 	= $('<li>').attr('id',uniq_id).data({'item':uniq_id,size:size});
		li.append(hidden_input);
		$image_list_obj.append(li);
	};
	*/
	/**
	 * @param key
	 */
	var mapInitWrite = function(b_code,$obj){
		$("body").addClass("write_mode");
		$map_form = $('#map_form');
		board_code = b_code;
		total_file_size = 0;
		if($obj){
			$map_editor = $obj;
			$map_form.find('#map_subject').limitLength({max_byte:120},true);
			if(IE_VERSION < 10){
				CKEDITOR.replace( 'map_body',{
					filebrowserImageUploadUrl: '/ajax/post_image_upload.cm?board_code='+b_code
				});
			}else{
				$map_form.find('#map_body').setFroala({
					code : board_code,
					image_upload_url : "/ajax/post_image_upload.cm",
					file_upload_url : "/ajax/post_file_upload.cm",
					file_list_obj : $("#file_list")
				});
			}

			$map_form.find('#delete_cover_image').on('click',function(){
				MAP.deleteCoverImage();
			});

			$map_form.find('#upload_cover_image').setUploadImage({
				url : '/ajax/upload_image.cm',
				formData : {target : 'post', 'temp' : 'Y', 'param_name' : 'cover_image'}
			}, function (msg, data,res) {
				$.each(res.cover_image,function(i,file){
					if(file.tmp_idx > 0){
						$map_form.find('#cover_image').val(file.url);
						$map_form.find('#cover_image_tmp_no').val(file.tmp_idx);
						$map_form.find('#delete_cover_image').show();
						$('#board_container').toggleClass('bg_on',true);
						$('#board_container').find('._cover_image').css('background-image',"url("+CDN_UPLOAD_URL+file.url+")");
						$('#board_container').find('._cover_image_src').attr('src',CDN_UPLOAD_URL+file.url);
					}
				});
			});


			$(window).off('scroll.mobile_write resize.mobile_write').on('scroll.mobile_write resize.mobile_write',function(){
				var s_top = $(this).scrollTop();
				$('#board_container').find('._mobile_tool_bar').toggleClass('m_sticky_toolbar',s_top > 45);
				if($('#board_container').hasClass('bg_on'))
					$('#board_container').find('#toolbarContainer').toggleClass('pc_sticky_toolbar',s_top > 487);
				else
					$('#board_container').find('#toolbarContainer').toggleClass('pc_sticky_toolbar',s_top > 180);
			});

			$obj.find('._map_search').keypress(function(e){
				if(e.keyCode == '13'){
					mapAdressSearch($(this).val());
				}
			});

			$obj.find('#number').on('keydown').check_callnum();
		}

		if(!IS_MOBILE){
			$('#map_list_fold').find('._map_container').on('click', function(){
				var get_data = $('#gmap_' + b_code).gmap3({get : {id : $(this).attr('id')}});
				var info_close = $('#gmap_' + b_code).gmap3({get : {name : "infowindow"}});
				var pos_x = parseFloat($('#' + $(this).attr('id')).find('#pos_x_temp').val());
				var pos_y = parseFloat($('#' + $(this).attr('id')).find('#pos_y_temp').val());
				if(info_close){
					info_close.close();
				}
				var map_data = '';
				var count = 0;
				$('#gmap_' + b_code).gmap3({
					exec : {
						id : $(this).attr('id'),
						func : function(data){
							if(count == 4){
								map_data = data;
							}
							count++;
						}
					}
				});
				$('#gmap_' + b_code).gmap3({
					map : {
						options : {
							center : [pos_y, pos_x],
							scrollwheel : false,
							maxZoom : 19,
							minZoom : 3,
							mapTypeControl : false,
							streetViewControl : false
						}
					},
					infowindow : {
						anchor : get_data,
						options : {content : map_data}
					}
				});

				var map_comment_count = 0;
				var like_cnt = 0;
				var read_cnt = 0;
				var idx_arr = $(this).attr('id').split('list_');
				map_comment_count = Math.round($('#' + $(this).attr('id')).find('#comment_count').text());
				like_cnt = Math.round($('#' + $(this).attr('id')).find('#like_count').text());
				read_cnt = Math.round($('#' + $(this).attr('id')).find('#read_count').text());
				$('#list_pop_' + idx_arr[1]).find('#comment_count').text(map_comment_count);
				$('#list_pop_' + idx_arr[1]).find('#like_count').text(like_cnt);
				$('#list_pop_' + idx_arr[1]).find('#read_count').text(read_cnt);

			});
		}



		document.onkeydown = function(evt) {
			if(evt.keyCode == 27){
				$('html').removeClass('fullboard_on');
				$('body').find('#maps_more').remove();
				$('body').css('overflow','');
				location.hash = '';
				//$map_editor.hide();
				$('._calendar_modal_back').hide();
				if($map_form.find('#add_address_ck').val() == 'N'){
					searchDataClear('close');
				}
			}
		}


	};

	var deleteCoverImage = function(){
		$map_form.find('#cover_image').val('');
		$map_form.find('#cover_image_tmp_no').val('');
		$('#board_container').toggleClass('bg_on',false);
		$('#board_container').find('._cover_image').css('background-image','none');
		$('#board_container').find('._cover_image_src').attr('src','');
		$map_form.find('#delete_cover_image').hide();
	};

	var toggleAlarmPopup = function(){
		$('#alarm_popup').toggleClass('open');
		if($('#alarm_popup').hasClass('open')){
			$(window).on('click.alarm_popup',function(event){
				var $top_closest = $(event.target).closest('a');
				if($top_closest.attr('id')!='dLabel'){
					var $closest = $(event.target).closest('ul');
					if($closest != null && !$closest.hasClass('dropdown-menu')){
						$('#alarm_popup').removeClass('open');
						$(window).off('click.alarm_popup');
						var alarm_group_list = $('#alarm_popup').find("input[type='checkbox']").is(":checked");
						if(alarm_group_list) $('#dLabel').addClass('active');
						else $('#dLabel').removeClass('active');
					}
				}
			});
		}
	};
	/**
	 *
	 * @param data
	 */
	var addMapData = function(data){
		map_data.push(data);
	};
	/**
	 *
	 * @param $obj
	 */
	var mapEditorPop = function(){
		$map_editor.show();
		$('._calendar_modal_back').show();
		if($map_form.find('#pos_x').val() && $map_form.find('#pos_y').val()){
			setGoogleMap($map_form.find('#pos_y').val(),$map_form.find('#pos_x').val(),17,'N');
		}else{
			setGoogleMap(37.5568708,126.9208862,17,'N');
		}

		if($map_form.find('#address').val()){
			$map_editor.find('._map_search').val($map_form.find('#address').val());
		}
		if($map_form.find('#sub_address').val()){
			$map_editor.find('#s_address').val($map_form.find('#sub_address').val());
		}
		if($map_form.find('#phone_number').val()){
			$map_editor.find('#number').val($map_form.find('#phone_number').val());
		}
		if($map_form.find('#web_address').val()){
			$map_editor.find('#h_address').val($map_form.find('#web_address').val());
		}

		$("body").off('mousedown.map').on('mousedown.map', function(e){
			var t3 = $(e.target);
			if(t3.closest('._map_moda_content').length == 0){
				$map_editor.hide();
				$('._calendar_modal_back').hide();
				if($map_form.find('#add_address_ck').val() == 'N'){
					searchDataClear('back');
				}
			}
		});

		$map_editor.find('._map_editor_close').on('click',function(){
			$map_editor.hide();
			$('._calendar_modal_back').hide();
			if($map_form.find('#add_address_ck').val() == 'N'){
				searchDataClear('close');
			}
		});

		$map_editor.find('._map_adress_add').on('click',function(){
			if(!$map_editor.find('._map_search').val()){
				alert(LOCALIZE.설명_주소장소를검색해주세요());
			}else{
				if(!$map_form.find('#temp_pos_x').val() && !$map_form.find('#temp_pos_y').val()){
					alert(LOCALIZE.설명_주소검색버튼을눌러주세요());
				}else{
					searchDataAdd();
				}
			}
		});
		$map_editor.find('#s_address,#number,#h_address').keypress(function(e){
			if(e.keyCode == '13'){
				if(!$map_editor.find('._map_search').val()){
					alert(LOCALIZE.설명_주소장소를검색해주세요());
				}else{
					searchDataAdd();
				}
			}
		});
	};
	/**
	 *
	 * @param val
	 * @param $obj
	 * @returns {boolean}
	 */
	var mapAdressSearch = function(val){
		if(val == '') {
			$map_editor.find('._search_result').hide();
			alert(LOCALIZE.설명_주소장소를검색해주세요());
			return false;
		}
		$.ajax({
			type: 'POST',
			data: {keyword: val},
			url: ('/admin/ajax/map_search.cm'),
			dataType: 'json',
			async: true,
			cache: false,
			success: function (res2) {
				$map_editor.find('._search_list').empty();
				if(res2.msg == 'SUCCESS'){
					if(res2.count > 0) {
						$.each(res2.data,function(e,_data){
							var item = $('<li><span class="txt">' + _data.address + '</span></li>').data({lat:_data.lat,lng:_data.lng,address:_data.address})
								.on('click', function () {
									$map_editor.find('._map_search').val($(this).data('address'));
									var tmp = {'lat': $(this).data('lat'), 'lng': $(this).data('lng'),'address' : $(this).data('address')};
									$map_editor.find('._search_result').hide();
									setGoogleMap($(this).data('lat'),$(this).data('lng'),17,'N');
									$map_form.find('#temp_pos_x').val($(this).data('lng'));
									$map_form.find('#temp_pos_y').val($(this).data('lat'));
								});
							$map_editor.find('._search_list').append(item);
						});
					}else {
						var item = $('<li><span class="txt">'+LOCALIZE.설명_검색결과가존재하지않습니다()+'</span></li>')
							.on('click', function () {
								$map_editor.find('._search_result').hide();
							});
						$map_editor.find('._search_list').append(item);
					}
					$map_editor.find('._search_result').show();
				}else{

					$map_editor.find('._search_result').hide();
				}
			}
		});
	};
	/**
	 *
	 * @param lat
	 * @param lng
	 * @param zoom
	 * @param $obj
	 */
	var setGoogleMap = function(lat,lng,zoom,detail,$obj,m_data){
		zoom = parseInt(zoom);
		var clickMarker;
		var latlng = new google.maps.LatLng(lat,lng);


		var myOptions = {
			zoom: zoom,
			center: latlng,
			mapTypeId: 'roadmap',
			zoomControl: true,
			mapTypeControl: false,
			scaleControl: false,
			streetViewControl: false,
			rotateControl: false,
			scrollwheel : false,
			disableDoubleClickZoom : true,
			gestureHandling:'cooperative'
		};

		var styles = [
			{
				stylers: [
					{ saturation: -20 }
				]
			},{
				featureType: "road",
				elementType: "geometry",
				stylers: [
					{ lightness: 100 },
					{ visibility: "simplified" }
				]
			},{
				featureType: "road",
				elementType: "labels",
				stylers: [
					{ visibility: "off" }
				]
			}
		];

		if($obj){
			$map = new google.maps.Map($obj.find('#_gmap').get(0), myOptions);
		}else{
			$map = new google.maps.Map($map_editor.find('#_gmap').get(0), myOptions);
		}
		$map.setOptions({styles: styles});

		clickMarker = new google.maps.Marker({
			position: latlng,
			map: $map,
			icon: '',
			shadow: null,
			title: name
		});

		if(detail == 'Y'){
			var info_name = '';
			var info_phone_number = '';
			var info_address = '';
			if(typeof m_data.subject != 'undefined' && m_data.subject != ''){
				info_name = '<header><div class="box_tit">' + m_data.subject + '</div></header>';
			}
			if(typeof m_data.address != 'undefined' && m_data.address != ''){
				if(typeof m_data.phone_number != 'undefined' && m_data.phone_number != ''){
					info_phone_number = '<span class="map_tell" style="display: block">' + m_data.phone_number + '</span>';
					info_address = '<p class="map_adress">' + m_data.address + info_phone_number + '</p>';
				}else{
					info_address = '<p class="map_adress">' + m_data.address + '</p>';
				}
			}

			if(info_name != '' || info_address != ''){
				var contentString1 = '<div class="map_info_box">' + info_name + info_address + '</div>';
				var infowindow = new google.maps.InfoWindow({
					content : contentString1
				});
				infowindow.open($map, clickMarker);
			}

			clickMarker.addListener('click', function(){
				infowindow.open($map, clickMarker);
			});
		}
	};

	var AddressDelete = function(){
		searchDataClear('delete');
	};


	var searchDataClear = function(type){
		if(type == 'back'){
			$map_form.find('#pos_x').val('');
			$map_form.find('#pos_y').val('');
			$map_form.find('#temp_pos_x').val('');
			$map_form.find('#temp_pos_y').val('');
			$map_editor.find('._map_search').val('');
			$map_editor.find('#s_address').val('');
			$map_editor.find('#number').val('');
			$map_editor.find('#h_address').val('');
		}else if(type == 'close'){
			$map_form.find('#pos_x').val('');
			$map_form.find('#pos_y').val('');
			$map_form.find('#temp_pos_x').val('');
			$map_form.find('#temp_pos_y').val('');
			$map_editor.find('._map_search').val('');
			$map_editor.find('#s_address').val('');
			$map_editor.find('#number').val('');
			$map_editor.find('#h_address').val('');
		}else if(type == 'delete'){
			$map_form.find('#add_address_ck').val('N');
			$map_form.find('#pos_x').val('');
			$map_form.find('#pos_y').val('');
			$map_form.find('#temp_pos_x').val('');
			$map_form.find('#temp_pos_y').val('');
			$map_form.find('#phone_number').val('');
			$map_form.find('#address').val('');
			$map_form.find('#sub_address').val('');
			$map_form.find('._add_map').removeClass('on');
			$map_form.find('._address').text('');
			$map_form.find('._phone').text('');
			$map_form.find('._web_address').text('');
			$map_form.find('#web_address').val('');
			$map_editor.find('._map_search').val('');
			$map_editor.find('#s_address').val('');
			$map_editor.find('#number').val('');
			$map_editor.find('#h_address').val('');
		}
	};

	var searchDataAdd = function(){
		$map_form.find('#address').val($map_editor.find('._map_search').val());
		$map_form.find('#sub_address').val($map_editor.find('#s_address').val());
		$map_form.find('#phone_number').val($map_editor.find('#number').val());
		$map_form.find('#web_address').val($map_editor.find('#h_address').val());
		$map_form.find('._add_map').addClass('on');
		$map_form.find('._address').text($map_editor.find('._map_search').val()+' '+$map_editor.find('#s_address').val());
		$map_form.find('._phone').text($map_editor.find('#number').val());
		$map_form.find('._web_address').text($map_editor.find('#h_address').val());
		$map_form.find('#add_address_ck').val('Y');
		$map_form.find('#pos_x').val($map_form.find('#temp_pos_x').val());
		$map_form.find('#pos_y').val($map_form.find('#temp_pos_y').val());
		$map_editor.hide();
		$('._calendar_modal_back').hide();
	};

	var mapSubmit = function(){
		var address = $map_form.find('input#address').val();
		if(address != ''){
			if(IE_VERSION < 10){
				var body = CKEDITOR.instances.map_body.getData();
				var plain_text = $(body).text();
				$map_form.find('#body_input').val(body);
				$map_form.find('#plain_body_input').val(plain_text);
				$map_form.submit();
			}else{
				if($map_form.find('#map_body').hasClass('fr-code-view'))
					$map_form.find('#map_body').froalaEditor('codeView.toggle');

				var body = $map_form.find('#map_body').froalaEditor("html.get", true, true);
				var plain_text = $(body).text();
				$map_form.find('#body_input').val(body);
				$map_form.find('#plain_body_input').val(plain_text);
				$map_form.submit();
			}
		}else{
			alert(LOCALIZE.설명_주소를입력하세요());
			mapEditorPop();
		}
	};

	var getTypeMapView = function(idx,back_url){
		$('html').addClass('fullboard_on');
		location.hash = '/map'+idx;
		back_url = back_url+location.hash;
		$.ajax({
			type		: 'post',
			data:{'idx':idx,'board_code':board_code,'back_url':back_url},
			url			: '/ajax/map_more_view.cm',
			dataType 	: 'json',
			async       : false,
			cache       : false,
			success		: function(result){
				if(result.msg == 'SUCCESS'){
						SNS.init(result.sns_init_data);
						$('[data-toggle="tooltip"]').tooltip();
						var $html = $(result.html);
						$('body').append($html);
						if(IS_ANDROID_APP == 'Y'){
							var height = 0;
							var org_height = 0;
							org_height = $("html,body").height();
							height = $("html,body").height()+100;
							$("html,body").css('height',height);
							$html.scroll(function(){
								$("html,body").scrollTop($(this).scrollTop());
							});
						}else{
							$('body').css('overflow','hidden');
						}
						if(!result.require_login && !result.deny && !result.require_pass){
							setGoogleMap(result.data.pos_y,result.data.pos_x,17,'N',$($('body').find('#maps_more')),result.data);
						}
						$(window).off('hashchange').on('hashchange',function(){
							var old_hash_url_tmp;
							var old_hash_url;
							var new_hash_url_tmp;
							var new_hash_url;
							old_hash_url_tmp = location.hash.split('#');
							if(old_hash_url_tmp[1]){
								old_hash_url = old_hash_url_tmp[1].split('map');
							}
							new_hash_url_tmp = back_url.split('#');
							new_hash_url = new_hash_url_tmp[1].split('map');
							if(!location.hash){
								$('body').find('#maps_more').remove();
								$('body').css('overflow','');
							}else{
								var hash_data_tmp;
								var hash_data;
								hash_data_tmp = location.hash.split('#');
								hash_data = hash_data_tmp[1].split('map');
								if(typeof hash_data[1] != 'undefined' && hash_data[1] != '' && hash_data[1] != 'null'){
									if(old_hash_url[1] != new_hash_url[1]){
										MAP.getTypeMapView(hash_data[1]);
									}
								}
							}
						});
						POST_COMMENT.init(result.data.code);
						$('body').find('#map_more_close').off('click').on('click',function(){
							$('html').removeClass('fullboard_on');
							if(IS_ANDROID_APP == 'Y'){
								$("html,body").css('height',org_height);
							}
							$('body').find('#maps_more').remove();
							$('body').css('overflow','');
							location.hash = '';
						});
					$html.find(".substance img").each(function(){
						if($(this).parent().get(0).tagName == 'A')
							return true;
						$(this).attr('data-src',$(this).attr('src')).data('src',$(this).attr('src')).addClass('_img_light_gallery');
					});
					$html.find(".substance").lightGallery({
						selector: '._img_light_gallery',
						thumbnail: false,
						animateThumb: false,
						showThumbByDefault: false
					});
					$('body').addClass('map_view');
				}else{
					alert(result.msg);
				}
			}
		});
	};

	var deleteMap = function (board_code,code,return_url){
		if(confirm(LOCALIZE.설명_삭제하시겠습니까())){
			$.ajax({
				type		: 'post',
				data:{'mcode':code,board_code:board_code},
				url			: '/ajax/deleteMap.cm',
				dataType 	: 'json',
				success		: function(result){
					if(result.msg == 'SUCCESS'){
						window.location.href = return_url;
					}else{
						alert(result.msg);
					}
				}
			});
		}
	};

	var mapListToggle = function($obj){
		if($obj.hasClass('fold') === true){
			$obj.removeClass('fold');
		}else{
			$obj.addClass('fold');
		}
	};

	var mapSearchToggle = function($obj,type){
		if(type == 'show'){
			$obj.find('.head_wrap').hide();
			$obj.find('.search-wrap').show();
		}
		if(type == 'hide'){
			$obj.find('.head_wrap').show();
			$obj.find('.search-wrap').hide();
		}
	};

	var mapListChange = function($obj,type){
		if(type=='map'){
			$obj.addClass('fold');
		}
		if(type=='list'){
			$obj.removeClass('fold');
		}
	};

	var posCreat = function(){
		if(!getCookie('lng') && !getCookie('lat')){
			var option = {
				enableHighAccuracy:false,
				timeout : 5000,
				maximumAge: 60000
			};
			if(navigator.geolocation){
				function success(pos) {
					clearTimeout(geolocation_timeout);
					var crd = pos.coords;
					map_list_current_position.latitude = crd.latitude;
					map_list_current_position.longitude = crd.longitude;
					if(getCookie('lat') != crd.latitude && getCookie('lng') != crd.longitude){
						setCookie('lat',crd.latitude,7);
						setCookie('lng',crd.longitude,7);
						location.reload();
					}
				}
				function error(err) {
					clearTimeout(geolocation_timeout);
					if(!(!!err)){
						err = {};
						err.code = 1;
					}
					switch (err.code) {
						case 0: //0: '위치 정보 검색에 문제가 있습니다.
							$(function(){
								alert(LOCALIZE.설명_위치정보검색에문제가있습니다());
							});
							break;
						case 1: //1: '현재 페이지에서 사용자가 위치 정보 검색을 거부했습니다.',
							$(function(){
								alert(LOCALIZE.설명_위치정보검색을허용해주세요());
							});
							break;
						case 2: //2: '브라우저가 위치정보를 검색하지 못했습니다.
							$(function(){
								alert(LOCALIZE.설명_위치정보를검색하지못했습니다());
							});
							break;
						case 3: //3: '브라우저의 위치 정보 검색 시간이 초과됐습니다.'
							$(function(){
								alert(LOCALIZE.설명_위치정보검색시간을초과하였습니다());
							});
							break;
						default:
							break;
					}
				}
				geolocation_timeout = setTimeout(error, option.timeout);
				navigator.geolocation.getCurrentPosition(success, error, option);
			}else{
				alert(LOCALIZE.설명_위치검색이지원되지않는브라우져입니다());
			}
		}
	};

	var posChange = function(){
		var option = {
			enableHighAccuracy:false,
			timeout : 5000,
			maximumAge: 60000
		};
		if(navigator.geolocation){
			function success(pos) {
				clearTimeout(geolocation_timeout);
				var crd = pos.coords;
				map_list_current_position.latitude = crd.latitude;
				map_list_current_position.longitude = crd.longitude;
				if(getCookie('lat') != crd.latitude && getCookie('lng') != crd.longitude){
					setCookie('lat',crd.latitude,7);
					setCookie('lng',crd.longitude,7);
				}
				location.reload();
			}
			function error(err) {
				clearTimeout(geolocation_timeout);
				if(!(!!err)){
					err = {};
					err.code = 1;
				}
				switch (err.code) {
					case 0: //0: '위치 정보 검색에 문제가 있습니다.
						$(function(){
							alert(LOCALIZE.설명_위치정보검색에문제가있습니다());
						});
						break;
					case 1: //1: '현재 페이지에서 사용자가 위치 정보 검색을 거부했습니다.',
						$(function(){
							alert(LOCALIZE.설명_위치정보검색을허용해주세요());
						});
						break;
					case 2: //2: '브라우저가 위치정보를 검색하지 못했습니다.
						$(function(){
							alert(LOCALIZE.설명_위치정보를검색하지못했습니다());
						});
						break;
					case 3: //3: '브라우저의 위치 정보 검색 시간이 초과됐습니다.'
						$(function(){
							alert(LOCALIZE.설명_위치정보검색시간을초과하였습니다());
						});
						break;
					default:
						break;
				}
			}
			geolocation_timeout = setTimeout(error, option.timeout);
			navigator.geolocation.getCurrentPosition(success, error, option);
		}else{
			alert(LOCALIZE.설명_위치검색이지원되지않는브라우져입니다());
		}
	};

	var listView = function(id,brand_color,show_like_cnt,show_cmt_cnt,shop_read_cnt,show_account){
		var list_data = [];
		var list_count = 0;
		var show_like_cnt_tag = '';
		var show_cmt_cnt_tag = '';
		var shop_read_cnt_tag = '';
		var show_account_tag = '';
		$.each(map_data,function(k,v){
			var value_obj = {};
			var back_link = $('#list_'+ v.idx).find('#back_url').val();
			//value_obj.address = v.address;
			value_obj.id = 'list_'+v.idx;
			value_obj.latLng = [v.pos_y,v.pos_x];
			if(show_like_cnt == 'Y'){
				show_like_cnt_tag = "<span class='comment_num no-padding-x no-pointer'>"+
					"<i class='icon-bubble vertical-middle' style='margin-right: 5px'></i>"+
					"<em id='comment_count'>"+v.comment_cnt+"</em>"+
					"</span>";
			}
			if(show_cmt_cnt == 'Y'){
				show_cmt_cnt_tag = "<span class='comment_num no-padding-x'>"+
					"<i class='icon-heart vertical-middle' style='margin-right: 5px'></i>"+
					"<em id='like_count'>"+v.like_cnt+"</em>"+
					"</span>";
			}
			if(shop_read_cnt == 'Y'){
				shop_read_cnt_tag = "<span class='comment_num no-padding-x'>"+
					"<i class='icon-eye vertical-middle' style='margin-right: 5px'></i>"+
					"<em id='read_count'>"+v.read_cnt+"</em>"+
					"</span>";
			}
			if(show_account == 'Y'){
				show_account_tag = "<p class='tell'>"+v.phone_number+"</p>";
			}
			if($('#list_'+ v.idx).find('img').attr('src')){
				value_obj.data =
				"<a href='javascript:;' onclick=\"MAP.getTypeMapView('"+v.idx+"','"+back_link+"')\">"+
				"<div class='map_container map_container_view map-inner $cover_class _map_container' id='list_pop_" + v.idx + "'>" +
						"<div class='thumb'>"+
							"<img src='"+$('#list_'+ v.idx).find('img').attr('src')+"'>"+
						"</div>"+
						"<div class='map_contents'>"+
							"<div class='head'>"+
								"<div class='tit'>"+v.subject+"</div>"+
							"</div>"+
							"<div class='p_group'> "+
								"<p class='adress'>"+v.address+"</p>"+
								show_account_tag+
							"</div>"+
							"<div class='btn-gruop btn-group-comment'>"+
								show_like_cnt_tag+
								show_cmt_cnt_tag+
								shop_read_cnt_tag+
							"</div>"+
							"<div class='map_contents_close'>"+
							"<a href='javascript:;' onclick=\"MAP.infowindowClose()\"><i class='btl bt-times'></i></a>"+
							"</div>"+
					"<a href='javascript:;'  onclick=\"MAP.getTypeMapView('" + v.idx + "','" + back_link + "')\" class='btn btn-xs' style='margin-top:15px; letter-spacing: 0; border-radius: 30px;'>"+LOCALIZE.버튼_상세보기()+ "</a>" +
						"</div>"+
					"</div>"+
				"</a>";
			}else{
				value_obj.data =
				"<a href='javascript:;' onclick=\"MAP.getTypeMapView('"+v.idx+"','"+back_link+"')\">"+
				"<div class='map_container  map-inner $cover_class _map_container' id='list_pop_" + v.idx + "'>" +
						"<div class='map_contents'>"+
							"<div class='head'>"+
								"<div class='tit'>"+v.subject+"</div>"+
							"</div>"+
							"<div class='p_group'> "+
								"<p class='adress'>"+v.address+"</p>"+
								show_account_tag+
							"</div>"+
							"<div class='btn-gruop btn-group-comment'>"+
								show_like_cnt_tag+
								show_cmt_cnt_tag+
								shop_read_cnt_tag+
						 	"</div>"+
							"<div class='map_contents_close'>"+
							"<a href='javascript:;' onclick=\"MAP.infowindowClose()\"><i class='btl bt-times'></i></a>"+
							"</div>"+
				"<a href='javascript:;'  onclick=\"MAP.getTypeMapView('" + v.idx + "','" + back_link + "')\" class='btn btn-xs' style='margin-top:15px; letter-spacing: 0; border-radius: 30px;'>"+LOCALIZE.버튼_상세보기()+"</a>" +
						"</div>"+
					"</div>"+
				"</a>";
			}
			list_data.push(value_obj);
			list_count++;
		});
		$(id).gmap3({
			map:{
				options:{
					center:[37.5568708,126.9208862],
					scrollwheel:false,
					maxZoom: 17,
					minZoom: 3,
					mapTypeControl:false,
					streetViewControl:false
				}
			},
			marker:{
				values:list_data,
				options:{
					draggable: false
					/*
					icon: {
						path: google.maps.FORWARD_CLOSED_ARROW,
						fillOpacity: 1,
						fillColor: 'black',
						strokeOpacity: 0,
						scale: 1,
						anchor: new google.maps.Point(23.0, 42.0)
					}
					*/
				},
				events:{
					click: function(marker, event, context){
						/*
						marker.setIcon({
							path: 'M24,4c-7.74,0-14,6.26-14,14c0,10.5,14,26,14,26s14-15.5,14-26C38,10.26,31.74,4,24,4z',
							fillOpacity: 1,
							fillColor: brand_color,
							strokeOpacity: 0,
							scale: 0.9,
							anchor: new google.maps.Point(23.0, 42.0)
						});
						*/

						var map = $(this).gmap3("get"),
							infowindow = $(this).gmap3({get:{name:"infowindow"}});
						if (infowindow){
							infowindow.open(map, marker);
							infowindow.setContent(context.data);
						} else {
							$(this).gmap3({
								infowindow:{
									anchor:marker,
									options:{content: context.data}
								}
							});
						}


						var map_comment_count = 0;
						var like_cnt = 0;
						var read_cnt = 0;
						var idx_arr = context.id.split('list_');
						map_comment_count = Math.round($('#'+context.id).find('#comment_count').text());
						like_cnt = Math.round($('#'+context.id).find('#like_count').text());
						read_cnt = Math.round($('#'+context.id).find('#read_count').text());
						$('#list_pop_'+idx_arr[1]).find('#comment_count').text(map_comment_count);
						$('#list_pop_'+idx_arr[1]).find('#like_count').text(like_cnt);
						$('#list_pop_'+idx_arr[1]).find('#read_count').text(read_cnt);
					}
				}
			},
			autofit:{}
		});
	};

	var infowindowClose = function(){
		var infowindow = $('#gmap_'+board_code).gmap3({get:{name:"infowindow"}});
		if (infowindow){
			infowindow.close();
		}
	};

	var mapSecretPost = function($obj,type){
		if(type == 'pc'){
			if($('#secret_input_pc').hasClass('active') === false){
				$obj.find('#secret_input_pc').addClass('active');
				$obj.find('#secret_input_nomember').addClass('active');
				$obj.find('#secret_input_mobile').addClass('active');
			}else{
				$obj.find('#secret_input_pc').removeClass('active');
				$obj.find('#secret_input_nomember').removeClass('active');
				$obj.find('#secret_input_mobile').removeClass('active');
			}
			if($('#secret_input_pc').hasClass('active') === true){
				$('#is_secret_input').val('Y');
			}else{
				$('#is_secret_input').val('N');
			}
		}
		if(type == 'nomember'){
			if($('#secret_input_nomember').hasClass('active') === false){
				$obj.find('#secret_input_pc').addClass('active');
				$obj.find('#secret_input_nomember').addClass('active');
				$obj.find('#secret_input_mobile').addClass('active');
			}else{
				$obj.find('#secret_input_pc').removeClass('active');
				$obj.find('#secret_input_nomember').removeClass('active');
				$obj.find('#secret_input_mobile').removeClass('active');
			}
			if($('#secret_input_nomember').hasClass('active') === true){
				$('#is_secret_input').val('Y');
			}else{
				$('#is_secret_input').val('N');
			}
		}
		if(type == 'mobile'){
			if($('#secret_input_mobile').hasClass('active') === false){
				$obj.find('#secret_input_pc').addClass('active');
				$obj.find('#secret_input_nomember').addClass('active');
				$obj.find('#secret_input_mobile').addClass('active');
			}else{
				$obj.find('#secret_input_pc').removeClass('active');
				$obj.find('#secret_input_nomember').removeClass('active');
				$obj.find('#secret_input_mobile').removeClass('active');
			}
			if($('#secret_input_mobile').hasClass('active') === true){
				$('#is_secret_input').val('Y');
			}else{
				$('#is_secret_input').val('N');
			}
		}
	};

	var postDeleteFile = function(id){
		var obj = $('#'+id);
		var size = obj.data('size');
		total_file_size -= size;
		obj.remove();
	};

	var postAddFile = function(filename,file_code,tmp_idx,size){
		var uniq_id = makeUniq('upfile_');
		total_file_size += size;
		var clear_ico = $('<i class="zmdi zmdi-close"></i>').data({'item':uniq_id,size:size}).click(function(e){
			postDeleteFile(uniq_id);
		});
		var hidden_input = '';
		if(file_code.length>0) {
			hidden_input = $('<input name="upload_files[]" value="' + file_code + '" type="hidden" />');
		}else if(Math.round(tmp_idx) > 0){
			hidden_input = $('<input name="temp_files[]" value="' + tmp_idx + '" type="hidden" />');
		}
		var li 	= $('<li>').attr('id',uniq_id).data({'item':uniq_id,size:size});
		li.append($('<span>'+ filename +'<em> &nbsp;'+ GetFileSize(size) +'</em></span>'));
		li.append(clear_ico);
		li.append(hidden_input);
		$("#file_list").append(li);
	};

	var userPosCreat = function(id){
		var list_data = [];
		var value_obj = {};
		var image = '/img/my_location_1x.png';
		value_obj.latLng = [getCookie('lat'),getCookie('lng')];
		list_data.push(value_obj);
		$(id).gmap3({
			map:{
				options:{
					center:[37.5568708,126.9208862],
					scrollwheel:false,
					maxZoom: 17,
					minZoom: 3,
					mapTypeControl:false,
					streetViewControl:false
				}
			},
			marker:{
				values:list_data,
				options:{
					draggable: false,
					 icon:image
				}
			},
			autofit:{}
		});
	};

	var sortChange = function(type,menu_url,ssl_ck){
		if(type == 'STREET'){
			if(!ssl_ck){
				alert(LOCALIZE.설명_거리순정렬이지원되지않습니다());
				location.href=menu_url+'?sort=TIME';
			}else{
				location.href=menu_url+'?sort='+type;
			}
		}else{
			location.href=menu_url+'?sort='+type;
		}
	};

	return {
		init: function(b_code,$obj) {
			mapInitWrite(b_code,$obj);
		},
		toggleAlarmPopup : function(){
			toggleAlarmPopup();
		},
		addMapData : function(data){
			addMapData(data);
		},
		mapEditorPop : function(){
			mapEditorPop();
		},
		mapAdressSearch : function(val){
			mapAdressSearch(val);
		},
		AddressDelete : function(){
			AddressDelete();
		},
		submit : function(){
			mapSubmit();
		},
		setGoogleMap : function(lat,lng,zoom,detail,$obj,m_data){
			setGoogleMap(lat,lng,zoom,detail,$obj,m_data);
		},
		getTypeMapView : function(idx,back_url){
			getTypeMapView(idx,back_url);
		},
		deleteMap : function(board_code,code,return_url){
			deleteMap(board_code,code,return_url);
		},
		mapListToggle : function($obj){
			mapListToggle($obj);
		},
		mapSearchToggle : function($obj,type){
			mapSearchToggle($obj,type);
		},
		mapListChange : function($obj,type){
			mapListChange($obj,type);
		},
		posCreat : function(){
			posCreat();
		},
		posChange : function(){
			posChange();
		},
		listView : function(id,brand_color,show_like_cnt,show_cmt_cnt,shop_read_cnt,show_account){
			listView(id,brand_color,show_like_cnt,show_cmt_cnt,shop_read_cnt,show_account);
		},
		mapSecretPost : function($obj,type){
			mapSecretPost($obj,type);
		},
		'addFile' : function(filename,file_code,tmp_idx,size){
			postAddFile(filename,file_code,tmp_idx,size);
		},
		'infowindowClose':function(){
			infowindowClose();
		},
		'userPosCreat':function(id){
			userPosCreat(id);
		},
		'sortChange' : function(type,menu_url,ssl_ck){
			sortChange(type,menu_url,ssl_ck);
		},
		'deleteCoverImage' : function(){
			deleteCoverImage();
		}
	};
}();