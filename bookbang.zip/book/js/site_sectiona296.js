var section_youtube_list = [];

$(function(){
	var $youtube_player_api = $('#youtube_player_api');
	if($youtube_player_api.length == 0){
		$youtube_player_api = $('<script src="//www.youtube.com/player_api" id="youtube_player_api"></script>');
		var $first_script = $('script').eq(0);
		$first_script.before($youtube_player_api);
	}
});
function onYouTubeIframeAPIReady() {
	$.each(section_youtube_list,function(_e, _data){
		var player = new SITE_SECTION_YOUTUBE();
		player.init(_data.type,_data.code,_data.id);

	});
}
var SITE_SECTION_YOUTUBE = function(){
	var type;
	var tv;
	var vid;
	var playerDefaults = {'autoplay': 1, 'autohide': 1, 'modestbranding': 0, 'rel': 0, 'showinfo': 0, 'controls': 0, 'disablekb': 1, 'enablejsapi': 1, 'iv_load_policy': 3};
	var screen_code;
	var id;
	var $vb;
	var $screen;
	var code;
	var currVid = 0;
	var $section_obj;

	var init = function(t,c,d){
		type = t;
		code = c;
		id = d;
		if(type == 'section'){
			screen_code = "screen_"+code;
			$section_obj = $('#' + code);
		}
		if(type == 'visual'){
			screen_code = "screen_"+code+"_"+id;
			$section_obj = $('#visual_' + code);
		}
		vid = [ {'videoId': id, 'startSeconds': 0, 'endSeconds': 0, 'suggestedQuality': 'hd720'}];

		youTubePlayer();
	};

	var youTubePlayer  = function (){
		$section_obj.imagesLoaded()
			.always(function(){
				tv = new YT.Player(screen_code, {events: {'onReady': onPlayerReady, 'onStateChange': onPlayerStateChange}, playerVars: playerDefaults});
			});

	};

	var onPlayerReady = function(){
		if(type == 'section'){
			screen_code = "screen_"+code;
		}
		if(type == 'visual'){
			screen_code = "screen_"+code+"_"+id;
		}
		$screen = $('#' + screen_code);
		tv.loadVideoById(vid[currVid]);
		tv.mute();
		vidRescale();
		$('body').off('gridChange.'+code).on('gridChange.'+code,function(){
			vidRescale();
		});
		$(window).on('resize', function(){
			vidRescale();
		});
	};


	var onPlayerStateChange = function(e) {
		if (e.data === 1){
			$screen.addClass('active');
		} else if (e.data === 0){
			$screen.removeClass('active');
			if(currVid === vid.length - 1){
				currVid = 0;
			} else {
				currVid++;
			}
			tv.loadVideoById(vid[currVid]);
			tv.seekTo(vid[currVid].startSeconds);
		}
	};

	var vidRescale = function(){
		var w = $section_obj.outerWidth()+20,
			h = $section_obj.outerHeight()+20;
		if (w/h > 16/9){ //납작하다는 애기
			tv.setSize(w, w/16*9);
			$screen.css({'left': '-10px', 'top':'-10px'});
		} else { //길죽할때
			tv.setSize(h*(16/9), h);
			$screen.css({'left': -(($screen.outerWidth()-w)/2)-10 , "top":"-10px"});
		}
	};
	
	return {
		'init' : function(t,c,d){
			init(t,c, d);
		}
	}

};


var SECTION_RESIZE = function(){
	var code;
	var $section;
	var org_inside_width;
	var $main;
	var $aside;
	var $gutter;
	var $inside;
	var init = function(c){
		code = c;
		$section = $('#'+c);
		$main = $section.find('main');
		$aside = $section.find('div[doz_type="aside"]');
		$gutter = $section.find('div._side_gutter');
		$inside = $section.find('main > div[doz_type="inside"]');
		org_inside_width = parseInt($inside.css('width'));
		run();
	};

	var run = function(){
		//calc();
		$(window).off('resize.section_resize_'+code).on('resize.section_resize_'+code,function(){
			//calc();
		});
	};

	var calc = function(){
		var main_width = $main.width();
		if($aside.css('display')=='none')
			return;
		var side_width = $aside.outerWidth() + parseInt($aside.css('margin-left')) + parseInt($aside.css('margin-right'));
		var gutter_width = $gutter.outerWidth();
		var inside_width = $inside.outerWidth();
		var t_width = side_width+gutter_width+inside_width;
		if(main_width < t_width){
			var term = t_width-main_width;
			$inside.outerWidth(inside_width-term);
		}else if(t_width < main_width){
			var term = main_width - t_width;
			$inside.outerWidth(inside_width+term);
		}else{
			$inside.outerWidth(parseInt(org_inside_width));
		}
	};

	return {
		'init' : function(c){
			init(c)
		}
	}
};

